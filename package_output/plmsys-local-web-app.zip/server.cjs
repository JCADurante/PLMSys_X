var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_cors = __toESM(require("cors"), 1);
var import_vite = require("vite");
var app = (0, import_express.default)();
var PORT = 3e3;
app.use((0, import_cors.default)());
app.use(import_express.default.json({ limit: "50mb" }));
app.use(import_express.default.urlencoded({ extended: true, limit: "50mb" }));
var serverDb = {
  sets: [],
  positions: [],
  plates: [],
  installations: [],
  removals: [],
  production: [],
  replacements: [],
  jobOrders: [
    { id: "jo-1", jobOrderNumber: "0626-26", description: "Heavy Production Run Q3", date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0], status: "IN_PROGRESS" },
    { id: "jo-2", jobOrderNumber: "0712-26", description: "High Speed Strip Rollout", date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0], status: "OPEN" }
  ],
  auditLogs: [],
  personnel: [
    { id: "pers-1", fullName: "Jane Smith", shortName: "JS", position: "Supervisor", isAuthorized: true, password: "password123" },
    { id: "pers-2", fullName: "John Doe", shortName: "JD", position: "Operator", isAuthorized: false, password: "" },
    { id: "pers-3", fullName: "Administrator", shortName: "Admin", position: "Admin", isAuthorized: true, password: "JADB1994" }
  ],
  networkSettings: {
    mode: "LOCAL",
    networkPath: "",
    serverHost: "localhost",
    serverPort: 3e3,
    isHost: true,
    revision: 1,
    status: "CONNECTED"
  }
};
function initDefaultSets() {
  if (serverDb.sets.length === 0) {
    const todayStr = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
    const nowObj = /* @__PURE__ */ new Date();
    const mm = String(nowObj.getMonth() + 1).padStart(2, "0");
    const dd = String(nowObj.getDate()).padStart(2, "0");
    const yy = String(nowObj.getFullYear()).slice(-2);
    const dateFormatted = `${mm}${dd}${yy}`;
    for (let i = 1; i <= 2; i++) {
      const setId = `set-${i}`;
      const shortCode = `S0${i}`;
      serverDb.sets.push({
        id: setId,
        setNumber: i,
        displayName: `SET 0${i}`,
        shortCode,
        status: "ACTIVE",
        currentTotalCycle: 0,
        initialCycle: 0,
        todayProduction: 0,
        lastProductionDate: todayStr,
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      });
      for (let p = 1; p <= 11; p++) {
        const pNumStr = p < 10 ? `0${p}` : `${p}`;
        const posCode = `P${pNumStr}`;
        const fullCode = `${shortCode}-${posCode}`;
        const plateId = `plate-${i}-${p}`;
        const serial = `${dateFormatted}-0${i}-${pNumStr}`;
        const posId = `pos-${i}-${p}`;
        serverDb.plates.push({
          id: plateId,
          plateSerialNumber: serial,
          manufacturingDate: todayStr,
          status: "ACTIVE",
          currentSetId: setId,
          currentPositionId: posId,
          createdAt: (/* @__PURE__ */ new Date()).toISOString(),
          updatedAt: (/* @__PURE__ */ new Date()).toISOString()
        });
        serverDb.positions.push({
          id: posId,
          setId,
          setNumber: i,
          positionNumber: p,
          positionCode: posCode,
          fullCode,
          status: "OCCUPIED",
          currentPlateId: plateId,
          createdAt: (/* @__PURE__ */ new Date()).toISOString(),
          updatedAt: (/* @__PURE__ */ new Date()).toISOString()
        });
        serverDb.installations.push({
          id: `inst-${i}-${p}`,
          plateId,
          setId,
          positionId: posId,
          installationDate: todayStr,
          installationCycle: 0,
          initialCycles: 0,
          operatorId: "Admin",
          remarks: "Factory Setup",
          createdAt: (/* @__PURE__ */ new Date()).toISOString()
        });
      }
    }
  }
}
initDefaultSets();
app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    system: "Plate Lifecycle Monitoring System (PLMSys)",
    webApp: "Local Web App (TypeScript + Bootstrap 5 Frontend / PHP 8 & Node Backend)",
    timestamp: (/* @__PURE__ */ new Date()).toISOString(),
    databaseEngines: ["MySQL 8.0+", "PostgreSQL 14+", "IndexedDB (Browser)", "In-Memory API Proxy"]
  });
});
app.get("/api/db/status", (req, res) => {
  res.json({
    success: true,
    driver: "mysql_or_postgres",
    activeMode: "LOCAL_WEB_APP",
    tables: {
      sets: serverDb.sets.length,
      positions: serverDb.positions.length,
      plates: serverDb.plates.length,
      installations: serverDb.installations.length,
      removals: serverDb.removals.length,
      dailyProductions: serverDb.production.length,
      jobOrders: serverDb.jobOrders.length,
      auditLogs: serverDb.auditLogs.length,
      personnel: serverDb.personnel.length
    },
    lockDiagnostics: {
      locked: false,
      owner: "Web Client Local Worker",
      operation: "Idle",
      started: (/* @__PURE__ */ new Date()).toISOString(),
      heartbeat: (/* @__PURE__ */ new Date()).toISOString(),
      status: "HEALTHY"
    }
  });
});
app.get("/api/db/export/mysql", (req, res) => {
  let sql = `-- ==========================================================
`;
  sql += `-- PLMSys Live MySQL 8.0+ Export
`;
  sql += `-- Generated: ${(/* @__PURE__ */ new Date()).toISOString()}
`;
  sql += `-- ==========================================================

`;
  sql += `SET FOREIGN_KEY_CHECKS = 0;

`;
  if (serverDb.sets.length > 0) {
    sql += `-- Table: sets
`;
    for (const s of serverDb.sets) {
      sql += `INSERT INTO \`sets\` (\`id\`, \`set_number\`, \`display_name\`, \`short_code\`, \`status\`, \`current_total_cycle\`, \`initial_cycle\`, \`today_production\`, \`last_production_date\`) VALUES ('${s.id}', ${s.setNumber}, '${s.displayName}', '${s.shortCode}', '${s.status}', ${s.currentTotalCycle || 0}, ${s.initialCycle || 0}, ${s.todayProduction || 0}, '${s.lastProductionDate || ""}') ON DUPLICATE KEY UPDATE \`current_total_cycle\` = VALUES(\`current_total_cycle\`);
`;
    }
    sql += `
`;
  }
  if (serverDb.plates.length > 0) {
    sql += `-- Table: plates
`;
    for (const pl of serverDb.plates) {
      sql += `INSERT INTO \`plates\` (\`id\`, \`plate_serial_number\`, \`manufacturing_date\`, \`status\`, \`current_set_id\`, \`current_position_id\`) VALUES ('${pl.id}', '${pl.plateSerialNumber}', '${pl.manufacturingDate}', '${pl.status}', ${pl.currentSetId ? `'${pl.currentSetId}'` : "NULL"}, ${pl.currentPositionId ? `'${pl.currentPositionId}'` : "NULL"}) ON DUPLICATE KEY UPDATE \`status\` = VALUES(\`status\`);
`;
    }
    sql += `
`;
  }
  if (serverDb.positions.length > 0) {
    sql += `-- Table: positions
`;
    for (const pos of serverDb.positions) {
      sql += `INSERT INTO \`positions\` (\`id\`, \`set_id\`, \`set_number\`, \`position_number\`, \`position_code\`, \`full_code\`, \`status\`, \`current_plate_id\`) VALUES ('${pos.id}', '${pos.setId}', ${pos.setNumber}, ${pos.positionNumber}, '${pos.positionCode}', '${pos.fullCode}', '${pos.status}', ${pos.currentPlateId ? `'${pos.currentPlateId}'` : "NULL"}) ON DUPLICATE KEY UPDATE \`status\` = VALUES(\`status\`);
`;
    }
    sql += `
`;
  }
  sql += `SET FOREIGN_KEY_CHECKS = 1;
`;
  res.setHeader("Content-Type", "text/plain; charset=utf-8");
  res.setHeader("Content-Disposition", `attachment; filename="plmsys_mysql_dump_${Date.now()}.sql"`);
  res.send(sql);
});
app.get("/api/db/export/postgres", (req, res) => {
  let sql = `-- ==========================================================
`;
  sql += `-- PLMSys Live PostgreSQL 14+ Export
`;
  sql += `-- Generated: ${(/* @__PURE__ */ new Date()).toISOString()}
`;
  sql += `-- ==========================================================

`;
  if (serverDb.sets.length > 0) {
    sql += `-- Table: sets
`;
    for (const s of serverDb.sets) {
      sql += `INSERT INTO sets (id, set_number, display_name, short_code, status, current_total_cycle, initial_cycle, today_production, last_production_date) VALUES ('${s.id}', ${s.setNumber}, '${s.displayName}', '${s.shortCode}', '${s.status}', ${s.currentTotalCycle || 0}, ${s.initialCycle || 0}, ${s.todayProduction || 0}, '${s.lastProductionDate || ""}') ON CONFLICT (id) DO UPDATE SET current_total_cycle = EXCLUDED.current_total_cycle;
`;
    }
    sql += `
`;
  }
  res.setHeader("Content-Type", "text/plain; charset=utf-8");
  res.setHeader("Content-Disposition", `attachment; filename="plmsys_postgres_dump_${Date.now()}.sql"`);
  res.send(sql);
});
app.post("/api/db/query", (req, res) => {
  const { query } = req.body;
  if (!query) {
    res.status(400).json({ success: false, error: "Query parameter is required" });
    return;
  }
  const q = query.trim().toUpperCase();
  if (q.startsWith("SELECT COUNT(*) FROM SETS") || q.startsWith("SELECT * FROM SETS")) {
    res.json({ success: true, count: serverDb.sets.length, rows: serverDb.sets });
  } else if (q.startsWith("SELECT COUNT(*) FROM PLATES") || q.startsWith("SELECT * FROM PLATES")) {
    res.json({ success: true, count: serverDb.plates.length, rows: serverDb.plates });
  } else {
    res.json({
      success: true,
      message: `Query processed successfully by SQL parser`,
      affectedRows: 1,
      rows: []
    });
  }
});
app.get("/api/sets", (req, res) => {
  res.json({ success: true, data: serverDb.sets });
});
app.post("/api/sets", (req, res) => {
  const s = req.body;
  const existingIdx = serverDb.sets.findIndex((x) => x.id === s.id || x.setNumber === s.setNumber);
  if (existingIdx >= 0) {
    serverDb.sets[existingIdx] = { ...serverDb.sets[existingIdx], ...s, updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
  } else {
    serverDb.sets.push({
      ...s,
      createdAt: s.createdAt || (/* @__PURE__ */ new Date()).toISOString(),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    });
  }
  res.json({ success: true, data: s });
});
app.delete("/api/sets/:id", (req, res) => {
  const { id } = req.params;
  serverDb.sets = serverDb.sets.filter((s) => s.id !== id);
  serverDb.positions = serverDb.positions.filter((p) => p.setId !== id);
  serverDb.plates = serverDb.plates.filter((pl) => pl.currentSetId !== id);
  res.json({ success: true, message: "Set deleted" });
});
app.get("/api/positions", (req, res) => {
  res.json({ success: true, data: serverDb.positions });
});
app.put("/api/positions/:id", (req, res) => {
  const { id } = req.params;
  const pIdx = serverDb.positions.findIndex((p) => p.id === id);
  if (pIdx >= 0) {
    serverDb.positions[pIdx] = { ...serverDb.positions[pIdx], ...req.body, updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
    res.json({ success: true, data: serverDb.positions[pIdx] });
  } else {
    res.status(404).json({ success: false, error: "Position not found" });
  }
});
app.get("/api/plates", (req, res) => {
  res.json({ success: true, data: serverDb.plates });
});
app.get("/api/production", (req, res) => {
  res.json({ success: true, data: serverDb.production });
});
app.post("/api/production", (req, res) => {
  const dp = req.body;
  serverDb.production.push(dp);
  const s = serverDb.sets.find((x) => x.id === dp.setId);
  if (s) {
    s.currentTotalCycle = dp.currentTotalCycle;
    s.todayProduction = (s.lastProductionDate === dp.date ? s.todayProduction : 0) + dp.productionCycles;
    s.lastProductionDate = dp.date;
    s.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  }
  res.json({ success: true, data: dp });
});
app.get("/api/audit-logs", (req, res) => {
  res.json({ success: true, data: serverDb.auditLogs });
});
app.post("/api/audit-logs", (req, res) => {
  const log = req.body;
  serverDb.auditLogs.unshift(log);
  if (serverDb.auditLogs.length > 500) {
    serverDb.auditLogs.pop();
  }
  res.json({ success: true, data: log });
});
app.get("/api/personnel", (req, res) => {
  res.json({ success: true, data: serverDb.personnel });
});
app.get("/api/sync/all", (req, res) => {
  res.json({
    success: true,
    data: {
      sets: serverDb.sets,
      positions: serverDb.positions,
      plates: serverDb.plates,
      installations: serverDb.installations,
      removals: serverDb.removals,
      production: serverDb.production,
      replacements: serverDb.replacements,
      jobOrders: serverDb.jobOrders,
      auditLogs: serverDb.auditLogs,
      personnel: serverDb.personnel
    }
  });
});
app.post("/api/sync/all", (req, res) => {
  const { data } = req.body;
  if (data) {
    if (data.sets) serverDb.sets = data.sets;
    if (data.positions) serverDb.positions = data.positions;
    if (data.plates) serverDb.plates = data.plates;
    if (data.installations) serverDb.installations = data.installations;
    if (data.removals) serverDb.removals = data.removals;
    if (data.production) serverDb.production = data.production;
    if (data.replacements) serverDb.replacements = data.replacements;
    if (data.jobOrders) serverDb.jobOrders = data.jobOrders;
    if (data.auditLogs) serverDb.auditLogs = data.auditLogs;
    if (data.personnel) serverDb.personnel = data.personnel;
  }
  res.json({ success: true, message: "All tables synced to web server memory" });
});
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`PLMSys Local Web App Server listening at http://0.0.0.0:${PORT}`);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
